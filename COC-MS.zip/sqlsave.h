#pragma once
#include "common.h"
#include <shared_mutex>

//---------- ����ģ�� ----------

struct verify_token {
    int64_t id = 0;
    int64_t user_id = 0;
    std::string token;
    int is_use = 0;
    bool dirty = false;
};

struct mail {
    int64_t id = 0;
    int64_t user_id = 0;
    std::string title;
    std::string content;
    int64_t send_time = 0;
    int is_new = 1;
    std::string form_name;
    int64_t out_time = 0;
    std::string item_json;
    int is_claim = 0;
    bool dirty = false;
};

struct sever_list {
    int64_t id = 0;
    int64_t user_id = 0;
    std::string ip;
    std::string name;
    std::string introduction;
    int type = 0;
    int is_test = 0;
    int64_t last_updata = 0;
    bool dirty = false;
};

struct ban_history {
    int64_t id = 0;
    int64_t user_id = 0;
    int64_t start_ban_time = 0;
    int64_t end_ban_time = 0;
    int ban_reason = 0;
    bool dirty = false;
};

struct user {
    int64_t id = 0;
    std::string nickname;
    bool is_official = false;
    std::string avatar;
    std::string username;
    std::string password;
    int permission_id = 1;
    std::string token;
    std::string api_key;
    std::string email;
    std::string sign;
    int user_group = 1;
    std::string login_ip;
    int64_t registration_time = 0;
    int64_t last_time = 0;
    std::string ban_reason;
    int64_t start_ban_time = 0;
    int64_t end_ban_time = 0;
    bool dirty = false;
};

struct login_token {
    int64_t id = 0;
    int64_t user_id = 0;
    std::string token;
    std::string ip;
    int64_t create_time = 0;
    std::string device_name;
    int64_t expire_time = 0;
    bool dirty = false;
};

using PermissionMap = std::unordered_map<std::string, int>;
class PermissionCache {
public:
    void loadAll(std::shared_ptr<class ConnectionPool> pool);
    const PermissionMap* get(int64_t permission_id) const;
    void refresh(std::shared_ptr<class ConnectionPool> pool);

private:
    mutable std::shared_mutex mtx_;
    std::unordered_map<int64_t, PermissionMap> cache_;
};

//���ӳ�
class ConnectionPool {
public:
    ConnectionPool(const std::string& host, int port,
        const std::string& user, const std::string& passwd,
        const std::string& schema, int poolSize = 10);
    ~ConnectionPool();

    //ͨ�� user.token ��ѯ�û�
    std::optional<user> token_user(const std::string& token);

    //ͨ���û�����ѯ�û�
    std::optional<user> nickname_user(const std::string& username);

    //ͨ���û�ID��ѯ�û�
    std::optional<user> id_user(int64_t user_id);

    //ͨ�� login_token �ַ�����ѯ�Ự��¼
    std::optional<login_token> logintoken(const std::string& token);

    //ͨ�� verify_token ��ѯһ��������
    std::optional<struct verify_token> vetoken(const std::string& token);

    //��ѯĳ�û����ʼ��б�
    std::vector<struct mail> id_user(int64_t user_id, int limit);

    //ͨ�� token ���û�
    std::optional<user> token_id(const std::string& token);

    //ͨ���û������û�
    std::optional<user> queryUserByUsername(const std::string& username);

    //����Ա��ȫ���û��б�
    std::vector<user> get_user_list(int offset, int limit);

    //��ȡһ�����ݿ�����
    std::unique_ptr<sql::Connection> getConnection(int timeout_ms = 5000);

    //�黹���ӵ���
    void releaseConnection(std::unique_ptr<sql::Connection> conn);

    //д

    //����login_token
    bool s_logintoken(int64_t user_id, const std::string& token,
        const std::string& ip, const std::string& device_name,
        int64_t create_time, int64_t expire_time);

    //����user����token
    bool s_usertoken(int64_t user_id, const std::string& new_token);

    //�������û�
    bool s_user(const std::string& username, const std::string& password,
        int64_t reg_time, int64_t& out_user_id);

    //����user_verify_token
    bool s_verifytoken(int64_t user_id, const std::string& token);

    //ɾverify_token
    bool use_verifytoken(const std::string& token);

private:
    sql::ConnectOptionsMap opts_;
    std::queue<std::unique_ptr<sql::Connection>> pool_;
    std::mutex mutex_;
    std::condition_variable cv_;
    std::string host_, user_, passwd_, schema_;
    int port_;
    int poolSize_;
    sql::Driver* driver_;
};

class sqlsave {
public:
    PermissionCache perm_cache;

    sqlsave(const std::string& host, int port,
        const std::string& user, const std::string& password,
        const std::string& dbname);
    bool start();
    std::shared_ptr<ConnectionPool> getPool();
    void refreshServers();

    // �̰߳�ȫ�����ط������б�����
    std::vector<sever_list> getServersSnapshot() const;

private:
    std::shared_ptr<ConnectionPool> pool_;
    std::string host_, user_, passwd_, dbname_;
    int port_;

    // ��������
    mutable std::shared_mutex servers_mtx_;
    std::unordered_map<int64_t, std::unique_ptr<sever_list>> servers_by_id;
};
extern std::unique_ptr<sqlsave> g_db;