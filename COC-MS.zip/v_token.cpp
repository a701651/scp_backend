#include"v_token.h"
#include"common.h"
#include"sqlsave.h"
#include"othertool.h"
using namespace std;
/*״̬��:
* 0:�ɹ�
* 1:tokenΪ��
* 2:token��Ч
* 3:����ʧ��
* 4:��Ȩ��
*/
int v_token(const std::string& token, std::string& out) {
    if (token.empty()) return 1;
    auto opt_user = check_permission_get_user(token, { "get_user_verify_token" });
    if (!opt_user.has_value()) return 4;   // ��Ȩ�� �� token��Ч
    auto pool = g_db->getPool();
    std::string vtoken = encrypt::GenerateToken();
    if (!pool->s_verifytoken(opt_user->id, vtoken)) return 3;
    out = vtoken;
    return 0;
}
