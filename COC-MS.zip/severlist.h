#pragma once
#include"common.h"
using namespace std;
/*
* 0: �ɹ�
*/
int severlist(string& out);